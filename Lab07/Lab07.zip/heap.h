typedef struct{
	int prox;
	int id;
}Item;

typedef struct{
	Item *v;
	int tam;
}Heap;

void inserir(Heap *fila, Item x);

void aumentaPrioridade(Heap *fila, int i, int x);

void diminuiPrioridade(Heap *fila, int i, int x);

Item removerMax(Heap *fila);
