#include <stdio.h>
#include "heap.h"

int esq(int i){
	return 2*i + 1;
}

int dir(int i){
	return 2*i+2;
}

int pai(int i){
	return (i-1)/2;
}

void troca(Item *a, Item *b){
	int tempId = a->id, tempProx = a->prox;
	a->id = b->id;
	a->prox = b->prox;
	b->id = tempId;
	b->prox = tempProx;
}

void desce(Heap *fila, int i){
	int maior = i;
	int fEsq = esq(i), fDir = dir(i);	

	
	if(fDir < fila->tam && fila->v[fDir].prox > fila->v[i].prox){
		maior = fDir;
	}

	if(fEsq < fila->tam && fila->v[fEsq].prox >= fila->v[maior].prox){
		maior = fEsq;
	}
	
	if(i != maior){
		troca(&fila->v[i], &fila->v[maior]);
		desce(fila, maior);
	}
}

void sobe(Heap *fila, int i){
	int p = pai(i);
	if(i != 0 && fila->v[i].prox > fila->v[p].prox){
		troca(&fila->v[i], &fila->v[p]);
		sobe(fila,p);
	}	
}

void inserir(Heap *fila, Item x){	
	fila->v[fila->tam] = x;
	sobe(fila,fila->tam);
	fila->tam++;
}

void aumentaPrioridade(Heap *fila, int i, int x){
	fila->v[i].prox = x;
	sobe(fila,i);
}

void diminuiPrioridade(Heap *fila, int i, int x){
	fila->v[i].prox = x;
	desce(fila,i);
}

Item removerMax(Heap *fila){
	Item max = fila->v[0];
	fila->v[0].prox = fila->v[fila->tam-1].prox;
	fila->v[0].id = fila->v[fila->tam-1].id;
	fila->tam--;
	desce(fila, 0);
	
	return max;
}


