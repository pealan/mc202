#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "hashtable.h"

//Registro de um jogador em uma determinada rodada
typedef struct{
	int acertou;
	int qtPalavraCerta;//N° de vezes que a palavra escolhida por ele aparece no texto
	int total;//Pontuacao
}Jogador;


void acharProx(char **texto, TabelaHash *t, int tamTexto,char **frase, int tamFrase, int *depois, int *totalDepois){
   No *prim = buscar(t,frase[0]);
   *totalDepois = 0;
   int posProx,achouFrase,i,j;

   //Para todas as ocorrencias da primeira palavra da frase
   for(i = 0; i<prim->ult; i++){
      achouFrase = 1;
      posProx = prim->oc[i]+1;
      if(tamFrase > 1){
         for(j = 1; j<tamFrase && posProx<tamTexto; j++){
            if (strcmp(texto[posProx],frase[j]) != 0){
               achouFrase = 0;
               break;
            }
            posProx++;
         }

			if(posProx < tamTexto-1){//Se possui sucessor
         	if(achouFrase){
            	depois[(*totalDepois)] = posProx;
            	(*totalDepois)++;
         	}
			}
      }else{//Frase so tem uma palavra
			if(posProx < tamTexto-1){//se nao eh ultima palavra do texto
         	depois[(*totalDepois)] = posProx;
         	(*totalDepois)++;
			}
      }
   }
}

int main(){
   TabelaHash *t = NULL;
   char palpite[MAX];
   char **txt;//Vetor com todas as palavras do texto
   char **frase;//Vetor de palavras da frase
   int *depois;//Vetor com todas as posicoes das palavras sucessoras da frase
   int totalDepois;//tamanho do vetor das palavras sucessoras
   int n,i;
	
	//Tamanho do texto
   scanf("%d",&n);

   iniciarTabela(&t,n);

   txt = malloc(n*sizeof(char*));
   frase = malloc(n*sizeof(char*));//Frase da rodada tem no maximo todo o texto
   depois = malloc(n*sizeof(int));

   for(i = 0; i<n; i++){
      txt[i] = malloc(MAX*sizeof(char));
      frase[i] = malloc(MAX*sizeof(char));
   }

   for(i = 0; i<n; i++){
      scanf("%s",txt[i]);
      inserirNovo(t,txt[i],i);
   }

   int j,k,rodadas,part, repet,l, alguemAcertou;

   scanf("%d %d",&rodadas,&part);

   Jogador **pontuacao = malloc(rodadas*sizeof(Jogador*));

   for(i = 0; i<rodadas; i++){
      alguemAcertou = 0;

      //Aloca espaco na tabela para essa rodada
      pontuacao[i] = malloc(part*sizeof(Jogador));

      scanf("%d",&k);

      //Le a frase da rodada
      for(j = 0; j< k; j++){
         scanf("%s",frase[j]);
      }

		//Armazena em "depois" palavras que sucedem a frase 
      acharProx(txt,t,n,frase,k,depois,&totalDepois);

      //Para cada participante
      for(j = 0; j<part; j++){
         repet = 0;
         scanf("%s",palpite);

         for(l = 0; l < totalDepois; l++){
            if(strcmp(txt[depois[l]],palpite) == 0){
               repet++;
            }
         }

         if(i == 0){//Primeira rodada
            if(repet>0){//Ninguem perde pontos
               pontuacao[i][j].total = 100*repet;					
            }else{
					pontuacao[i][j].total = 0;
				}
         }else{
            if(repet>0){
               pontuacao[i][j].qtPalavraCerta = repet;
					pontuacao[i][j].acertou = 1;
               alguemAcertou = 1;
            }else{//palpite errado
					pontuacao[i][j].acertou = 0;
            }
            
         }        
      }

		if(i!=0){
			for(j = 0; j<part; j++){
				if(pontuacao[i][j].acertou){//Soma a pontuacao anterior
					pontuacao[i][j].total = pontuacao[i-1][j].total + 100*pontuacao[i][j].qtPalavraCerta;
				}else if(alguemAcertou){
					pontuacao[i][j].total = pontuacao[i-1][j].total - 10*totalDepois;
					if(pontuacao[i][j].total < 0)
						pontuacao[i][j].total = 0;
				}else{//Todos erraram na rodada
					pontuacao[i][j].total = pontuacao[i-1][j].total;
				}
			}
		}
   }

	//Imprime resultados finais formatados e desaloca matriz
   for(i = 0; i<rodadas; i++){
		printf("Rodada %d: ",i+1);
      for(j = 0; j<part; j++){
         printf("%4d",pontuacao[i][j].total);
			if(j != part-1)
				printf(" ");			
      }
      printf("\n");
		free(pontuacao[i]);
   }
	free(pontuacao);

	//Desaloca texto e frase
	for(i = 0; i<n; i++){
      free(txt[i]);
      free(frase[i]);
   }
	free(txt);
	free(frase);

	//Desaloca hash table
	free(t->vet);
	free(t);

   return 0;
}
