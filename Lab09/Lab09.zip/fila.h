#ifndef FILA_H
#define FILA_H

typedef struct{
	int n;
	int distancia;
	int posCol;
	int posLin;
}Pixel;

typedef struct NoFila{
	Pixel item;
	struct NoFila *prox;
	struct NoFila *frente;
	struct NoFila *traseira;
	int tam;
}NoFila;

void inicializaFila(NoFila **f);

void enfileirar(NoFila **f, Pixel novo);

//Coloca pixel na frente da fila
void furarFila(NoFila **f, Pixel novo);

Pixel desenfileirar(NoFila **f);

int estaVazia(NoFila *f);

void liberaFila(NoFila **f);

Pixel preparaPixel(int n, int i, int j);

#endif
