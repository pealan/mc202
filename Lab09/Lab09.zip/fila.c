#include <stdlib.h>
#include <stdio.h>
#include "fila.h"

void inicializaFila(NoFila **f){
	*f = malloc(sizeof(NoFila));
	(*f)->frente = (*f)->traseira = NULL;
	(*f)->tam = 0;
}

void enfileirar(NoFila **f, Pixel novo){
	NoFila *n = malloc(sizeof(NoFila));
	n->item = novo;
	n->prox = NULL;

	if((*f)->traseira != NULL && (*f)->frente != NULL){
		(*f)->traseira->prox = n;
		(*f)->traseira = n;
	}else{
		(*f)->frente = (*f)->traseira = n;
	}

	(*f)->tam++;
}

void furarFila(NoFila **f, Pixel novo){
	NoFila *n = malloc(sizeof(NoFila));
	n->item = novo;
	n->prox = NULL;

	if((*f)->traseira != NULL && (*f)->frente != NULL){
		n->prox = (*f)->frente;
		(*f)->frente = n;//Coloca na frente
	}else{
		(*f)->frente = (*f)->traseira = n;
	}

	(*f)->tam++;
}

Pixel desenfileirar(NoFila **f){
	NoFila *t;
	Pixel temp;
	if((*f)->frente != NULL){
		t = (*f)->frente;

		if((*f)->frente == (*f)->traseira)
			(*f)->frente = (*f)->traseira = NULL;
		else
			(*f)->frente = t->prox;

		temp = t->item;
		free(t);
		(*f)->tam--;
	}
	
	return temp;
}

int estaVazia(NoFila *f){
	if(f->frente == NULL && f->traseira == NULL)
		return 1;

	return 0;
}

void liberaFila(NoFila **f){
	if(!estaVazia(*f)){
		NoFila *p = (*f)->frente->prox;
		NoFila *aux;
		while(p != NULL){
			aux = p->prox;
			free(p);
			p = aux;
		}
	}
}

Pixel preparaPixel(int n, int i, int j){
	Pixel p;
	p.n = n;
	p.posLin = i;
	p.posCol = j;
	p.distancia = 0;

	return p;
}
