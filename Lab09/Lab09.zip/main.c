/*Nome:Pedro Alan Tapia Ramos
 *RA:185531
 *Algoritmo de leitura e liberacao de imagem disponibilizados pelo IC
*/

#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include "fila.h"

#define PRETA 0
#define BRANCA 0xFFFFFF

typedef struct {
    int w, h;
    int **pix;
} Img;

// função presume que não ocorrem erros e que 
// máximo valor de valor de um canal de cor é 255
Img *ler_img() {
   Img *img;
   char peek;
   int i, j, r, g, b;
   assert(img = malloc(sizeof(*img)));
   scanf("P3 ");
 	while((peek = getchar()) == '#') scanf("%*[^\r\n]%*[\r\n]");
	ungetc(peek,stdin);
	assert(scanf("%d %d %*d", &img->w, &img->h)==2);
   assert(img->pix = malloc(sizeof(*img->pix) * img->h));
    for (i = 0; i < img->h; i++) {
        assert(img->pix[i] = malloc(sizeof(**img->pix) * img->w));
        for (j = 0; j < img->w; j++) {
            assert(scanf("%d%d%d", &r, &g, &b)==3);
            img->pix[i][j] = (r << 16) + (g << 8) + b;
        }
    }
    return img;
}

void libera_img(Img *img) {
    int i;
    for (i = 0; i < img->h; i++)
        free(img->pix[i]);
    free(img->pix);
    free(img);
}

Pixel acharInicio(Img *img){
	int i, j;
	Pixel ini = (Pixel){0};
	for (i = 0; i<img->h; i++){
		for (j = 0; j < img->w; j++){
			if(img->pix[i][j] == BRANCA){
				ini = preparaPixel(img->pix[i][j],i,j);
				return ini;
			}
		}
	}
	
	return ini;
}

//Coloca todos os adjacentes de u em um vetor v, dado o grafo implicito de um imagem
void adjacentes(Pixel *v, Pixel u, Img *img){
	int i,j;
	//Adjacencia cima/baixo
	i = u.posLin-1;
	j = u.posCol;

	if(i >= 0 && img->pix[i][j] != PRETA){		
		v[0] = preparaPixel(img->pix[i][j],i,j);
	}else{
		v[0] = (Pixel){0};//Coloca um adjacente como PRETA
	}

	i = u.posLin+1;
	if(i < img->h && img->pix[i][j] != PRETA){
		v[1] = preparaPixel(img->pix[i][j],i,j);
	}else{
		v[1] = (Pixel){0};
	}

	//Adjacencia esquerda/direita
	i = u.posLin;
	j = u.posCol-1;
	if(j >= 0 && img->pix[i][j] != PRETA){
		v[2] = preparaPixel(img->pix[i][j],i,j);
	}else{
		v[2] = (Pixel){0};
	}
	
	j = u.posCol+1;		
	if(j < img->w && img->pix[i][j] != PRETA){
		v[3] = preparaPixel(img->pix[i][j],i,j);
	}else{
		v[3] = (Pixel){0};
	}
} 

//Algoritmo de busca em largura de um grafo implicito, no caso, a imagem
int menorCaminho(Img *img, Pixel ini){
	NoFila *f = NULL;
	Pixel *v = malloc(4*sizeof(Pixel));//Um pixel u tem no maximo 4 pixels adjacentes
	inicializaFila(&f);

	//Enfileira o pixel inicial branco
	enfileirar(&f,ini);

	int i, j, menor = 0,aux;
	int achouFinal = 0;//Flag que sinaliza a chegada a proxima area branca
	Pixel u;
	while(!achouFinal){
		u = desenfileirar(&f);		

		adjacentes(v,u,img);

		for(i = 0; i<4 && !achouFinal; i++){//Para cada pixel adjacente
			if(v[i].n != PRETA){
				if(v[i].n == u.n ||(v[i].n == BRANCA)){
					v[i].distancia = u.distancia;
					if(v[i].n == u.n){
						furarFila(&f,v[i]);
						img->pix[v[i].posLin][v[i].posCol] = PRETA;
					}else if(v[i].distancia > 0){
						menor = v[i].distancia;
						achouFinal = 1;
					}
				}else{
					v[i].distancia = u.distancia+1;
					enfileirar(&f,v[i]);
					img->pix[v[i].posLin][v[i].posCol] = PRETA;
				}
			}
		}
		img->pix[u.posLin][u.posCol] = PRETA;		
	}

	free(v);
	liberaFila(&f);

	return menor;
}

int main(int argc, char *argv[]) {    
	Img *img = ler_img();

	//Acha o primeiro pixel branco da imagem
	Pixel inicio = acharInicio(img);

	int menor = menorCaminho(img,inicio);

	printf("Maria deve memorizar %d regioes.\n",menor);

   libera_img(img);

   return 0;
}


